/**
 * Clase principal de prueba.
 * Crea instancias de OrdenadorArreglos, invoca sus métodos
 * y muestra la comparación entre QuickSort y MergeSort.
 */
public class Main {

    public static void main(String[] args) {

        System.out.println("================================================");
        System.out.println("   PROGRAMACIÓN I – QuickSort vs MergeSort      ");
        System.out.println("   Universidad de Cundinamarca – Ext. Facatativá ");
        System.out.println("================================================\n");

        // ── Caso 1: arreglo desordenado general ──────────────────────────
        System.out.println("▶ CASO 1: Arreglo desordenado general");
        int[] datos1 = {38, 27, 43, 3, 9, 82, 10};
        ejecutarPrueba(datos1);

        // ── Caso 2: arreglo ya ordenado (caso borde) ─────────────────────
        System.out.println("\n▶ CASO 2: Arreglo ya ordenado");
        int[] datos2 = {1, 2, 3, 4, 5, 6, 7, 8};
        ejecutarPrueba(datos2);

        // ── Caso 3: arreglo ordenado de forma inversa ─────────────────────
        System.out.println("\n▶ CASO 3: Arreglo en orden inverso");
        int[] datos3 = {95, 80, 60, 45, 30, 15, 5};
        ejecutarPrueba(datos3);

        // ── Caso 4: arreglo con elementos repetidos ───────────────────────
        System.out.println("\n▶ CASO 4: Arreglo con elementos repetidos");
        int[] datos4 = {5, 3, 8, 3, 9, 1, 5, 7, 1};
        ejecutarPrueba(datos4);

        // ── Caso 5: arreglo de un solo elemento ───────────────────────────
        System.out.println("\n▶ CASO 5: Arreglo de un solo elemento");
        int[] datos5 = {42};
        ejecutarPrueba(datos5);
    }

    /**
     * Método auxiliar que encapsula la creación del objeto,
     * la ejecución de ambos ordenamientos y la comparación.
     *
     * @param datos arreglo de enteros a ordenar
     */
    private static void ejecutarPrueba(int[] datos) {
        OrdenadorArreglos ordenador = new OrdenadorArreglos(datos);
        ordenador.mostrarOriginal();
        ordenador.ordenarConQuickSort();
        ordenador.ordenarConMergeSort();
        ordenador.compararResultados();
    }
}
