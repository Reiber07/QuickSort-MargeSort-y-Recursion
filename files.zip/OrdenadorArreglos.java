/**
 * Clase que encapsula un arreglo de enteros y provee
 * métodos de ordenamiento mediante QuickSort y MergeSort recursivos.
 */
public class OrdenadorArreglos {

    // ── Atributos ──────────────────────────────────────────────────────────
    private int[] arregloOriginal;
    private int[] arregloQuickSort;
    private int[] arregloMergeSort;
    private int   tamano;

    // ── Constructor ────────────────────────────────────────────────────────
    public OrdenadorArreglos(int[] datos) {
        this.tamano          = datos.length;
        this.arregloOriginal = copiar(datos);
        this.arregloQuickSort = copiar(datos);
        this.arregloMergeSort = copiar(datos);
    }

    // ── Métodos públicos ───────────────────────────────────────────────────

    /** Muestra el arreglo original sin modificar. */
    public void mostrarOriginal() {
        System.out.println("Arreglo original:   " + arregloToString(arregloOriginal));
    }

    /** Aplica QuickSort y muestra el resultado. */
    public void ordenarConQuickSort() {
        arregloQuickSort = copiar(arregloOriginal);          // reinicia desde el original
        quickSort(arregloQuickSort, 0, tamano - 1);
        System.out.println("Resultado QuickSort:" + arregloToString(arregloQuickSort));
    }

    /** Aplica MergeSort y muestra el resultado. */
    public void ordenarConMergeSort() {
        arregloMergeSort = copiar(arregloOriginal);          // reinicia desde el original
        mergeSort(arregloMergeSort, 0, tamano - 1);
        System.out.println("Resultado MergeSort:" + arregloToString(arregloMergeSort));
    }

    /** Muestra una comparación lado a lado de ambos resultados. */
    public void compararResultados() {
        System.out.println("\n╔══════════════════════════════════════════════════╗");
        System.out.println("║           COMPARACIÓN DE RESULTADOS             ║");
        System.out.println("╠══════════════════════════════════════════════════╣");
        System.out.printf("║ %-48s ║%n", "Original  : " + arregloToString(arregloOriginal));
        System.out.printf("║ %-48s ║%n", "QuickSort : " + arregloToString(arregloQuickSort));
        System.out.printf("║ %-48s ║%n", "MergeSort : " + arregloToString(arregloMergeSort));
        System.out.println("╚══════════════════════════════════════════════════╝");
    }

    // ── QuickSort ──────────────────────────────────────────────────────────

    /**
     * Método recursivo principal de QuickSort.
     * Divide el arreglo alrededor de un pivote y ordena cada mitad.
     *
     * @param arr   arreglo a ordenar
     * @param bajo  índice izquierdo del subarreglo actual
     * @param alto  índice derecho del subarreglo actual
     */
    private void quickSort(int[] arr, int bajo, int alto) {
        if (bajo < alto) {
            int indicePivote = particionar(arr, bajo, alto);  // ubica el pivote
            quickSort(arr, bajo, indicePivote - 1);           // ordena lado izquierdo
            quickSort(arr, indicePivote + 1, alto);           // ordena lado derecho
        }
    }

    /**
     * Método auxiliar de QuickSort.
     * Coloca el pivote (último elemento) en su posición definitiva
     * dejando a su izquierda los menores y a su derecha los mayores.
     *
     * @return índice final del pivote
     */
    private int particionar(int[] arr, int bajo, int alto) {
        int pivote = arr[alto];
        int i      = bajo - 1;                    // índice del elemento menor

        for (int j = bajo; j < alto; j++) {
            if (arr[j] <= pivote) {
                i++;
                intercambiar(arr, i, j);
            }
        }
        intercambiar(arr, i + 1, alto);           // coloca el pivote en su lugar
        return i + 1;
    }

    /** Intercambia dos posiciones dentro de un arreglo. */
    private void intercambiar(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i]   = arr[j];
        arr[j]   = temp;
    }

    // ── MergeSort ──────────────────────────────────────────────────────────

    /**
     * Método recursivo principal de MergeSort.
     * Divide el arreglo en mitades hasta llegar a subarreglos de 1 elemento,
     * luego los combina en orden.
     *
     * @param arr    arreglo a ordenar
     * @param inicio índice izquierdo del subarreglo actual
     * @param fin    índice derecho del subarreglo actual
     */
    private void mergeSort(int[] arr, int inicio, int fin) {
        if (inicio < fin) {
            int medio = (inicio + fin) / 2;
            mergeSort(arr, inicio, medio);         // ordena mitad izquierda
            mergeSort(arr, medio + 1, fin);        // ordena mitad derecha
            combinar(arr, inicio, medio, fin);     // fusiona ambas mitades
        }
    }

    /**
     * Método auxiliar de MergeSort.
     * Fusiona dos subarreglos ya ordenados en uno solo ordenado.
     *
     * @param arr    arreglo que contiene ambos subarreglos
     * @param inicio primer índice del subarreglo izquierdo
     * @param medio  último índice del subarreglo izquierdo
     * @param fin    último índice del subarreglo derecho
     */
    private void combinar(int[] arr, int inicio, int medio, int fin) {
        int nIzq = medio - inicio + 1;
        int nDer = fin - medio;

        int[] izq = new int[nIzq];
        int[] der = new int[nDer];

        // Copia los datos a los arreglos temporales
        for (int i = 0; i < nIzq; i++) izq[i] = arr[inicio + i];
        for (int j = 0; j < nDer; j++) der[j] = arr[medio + 1 + j];

        int i = 0, j = 0, k = inicio;

        // Mezcla comparando elemento a elemento
        while (i < nIzq && j < nDer) {
            if (izq[i] <= der[j]) {
                arr[k] = izq[i];
                i++;
            } else {
                arr[k] = der[j];
                j++;
            }
            k++;
        }

        // Copia los elementos restantes de cada mitad (si los hay)
        while (i < nIzq) { arr[k] = izq[i]; i++; k++; }
        while (j < nDer)  { arr[k] = der[j]; j++; k++; }
    }

    // ── Utilidades ─────────────────────────────────────────────────────────

    /** Devuelve una copia independiente del arreglo recibido. */
    private int[] copiar(int[] origen) {
        int[] copia = new int[origen.length];
        for (int i = 0; i < origen.length; i++) {
            copia[i] = origen[i];
        }
        return copia;
    }

    /** Convierte un arreglo en su representación de cadena. */
    private String arregloToString(int[] arr) {
        StringBuilder sb = new StringBuilder(" [");
        for (int i = 0; i < arr.length; i++) {
            sb.append(arr[i]);
            if (i < arr.length - 1) sb.append(", ");
        }
        sb.append("]");
        return sb.toString();
    }

    // ── Getters ────────────────────────────────────────────────────────────

    public int[] getArregloOriginal()   { return copiar(arregloOriginal);   }
    public int[] getArregloQuickSort()  { return copiar(arregloQuickSort);  }
    public int[] getArregloMergeSort()  { return copiar(arregloMergeSort);  }
    public int   getTamano()            { return tamano;                    }
}
